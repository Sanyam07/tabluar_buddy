# kaggleBuddy

This is a machine learning libriary that i ofen used during competition and work, more features willed be added in the near future.  
How to install: pip install kaggleBuddy

## 命名规则
文件夹名：小子字母 + 下划线
函数名：下划线命名法, 参数等号左右不留空白

1. cd folder  
2. python3 setup.py sdist bdist_wheel  
3. python3 -m twine upload dist/*  

```
"""Brief description.

Detailed description.

Parameters
----------
default_parameter : type, optional (default = 5)
    Detailed description.
required_parameter : type_1 or type_2
    Detailed description.
    - 'value_1' : Detailed description.
    - 'value_2' : Detailed description.

Returns
-------
parameter : type
    Detailed description.

Examples
--------
Your code here.
"""
```
