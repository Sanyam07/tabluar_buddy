# kaggleBuddy

This is a machine learning libriary that i ofen used during competition and work, more features willed be added in the near future.
